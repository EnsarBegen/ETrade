﻿using BlackFriday.Core.Service;
using BlackFriday.Model.Entities;
using BlackFriday.WebUI.Areas.User.Models.Dtos;
using BlackFriday.WebUI.Models.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using static System.Formats.Asn1.AsnWriter;

namespace BlackFriday.WebUI.Areas.User.Controllers
{
    [Authorize]
    [Area("User")]
    public class CustomerController : Controller
    {
        private readonly ICoreService<Category> _categorydb;
        private readonly ICoreService<Product> _productdb;
        private readonly ICoreService<Customer> _customerdb;
        public CustomerController(ICoreService<Category> categorydb, ICoreService<Product> productdb, ICoreService<Customer> customerdb)
        {
            _categorydb = categorydb;
            _productdb = productdb;
            _customerdb = customerdb;
        }


        public IActionResult CategoryList()
        {
            return View(_categorydb.GetAll());
        }
        public IActionResult ProductList()
        {
            return View(_productdb.GetAll());
        }
        public IActionResult GetProduct(int id)
        {
            
            var result = _productdb.GetRecord(x => x.ID == id);

            var customerid = int.Parse(User.Claims.FirstOrDefault(c => c.Type.EndsWith("ID")).Value);
            var result2 = _customerdb.GetRecord(x => x.ID == customerid);
            


            var record = new ProductCustomerDto()
            {
                
                Name = result2.Name,
                Surname = result2.Surname,
                PhoneNumber = result2.PhoneNumber,
                Price = result.Price,
                ProductName = result.Name,
                Image = result.Image,
                Description = result.Description,

            };

            return View(record);
        }
        public IActionResult AddProduct(int id)
        {
            return View(_categorydb.GetByID(id));
        }
        [HttpPost]
        public IActionResult AddProduct(Category c, string name, string description, int price)
        {
            var id = int.Parse(User.Claims.FirstOrDefault(c => c.Type.EndsWith("ID")).Value);
            var result = _customerdb.GetRecord(x => x.ID == id);

            var record = new Product()
            {
                Name = name,
                Description = description,
                Price = price,
                CategoryID = c.ID,
                CustomerID = id

            };

            return _productdb.Add(record) ? RedirectToAction("ProductList", "Customer", new { Areas = "User" }) : View();
        }

        public IActionResult UpdateProduct(int id)
        {
            var customerid = int.Parse(User.Claims.FirstOrDefault(c => c.Type.EndsWith("ID")).Value);
            var result = _customerdb.GetRecord(x => x.ID == customerid);

            var product = _productdb.GetRecord(c => c.ID == id && c.CustomerID == result.ID);
            var category = _categorydb.GetByID(product.CategoryID);

            ProductUpdateDto record = new ProductUpdateDto()
            {
                CustomerID = result.ID,
                CategoryID = product.CategoryID,
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                ProductID =product.ID


            };

            return View(record);
        }
        [HttpPost]
        public IActionResult UpdateProduct(ProductUpdateDto pud)
        {

            var kayıt = _productdb.GetRecord(x => x.CustomerID == pud.CustomerID && x.ID == pud.ProductID && x.CategoryID ==pud.CategoryID);

            if (kayıt != null)
            {
                kayıt.Price = pud.Price;
                kayıt.Name = pud.Name;
                kayıt.Description = pud.Description;

                return _productdb.Update(kayıt) ? RedirectToAction("ProductList", "Customer", new { Areas = "User" }) : View();
            }

            return View();
        }
        public IActionResult DeleteProduct(int id)
        {
            return _productdb.Delete(id) ? View("ProductList", _productdb.GetAll()) : View();
        }
    }





}

