﻿namespace BlackFriday.WebUI.Areas.User.Models.Dtos
{
    public class ProductUpdateDto
    {
        
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        
        public int CustomerID { get; set; }
        public int ProductID { get; set; }
        public int CategoryID { get; set; }


    }
}
