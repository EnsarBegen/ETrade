﻿using BlackFriday.Core.Service;
using BlackFriday.Model.Entities;
using BlackFriday.WebUI.Models.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BlackFriday.WebUI.Controllers
{
    public class AccountController : Controller
    {
        private readonly ICoreService<Customer> _customer;

        public AccountController(ICoreService<Customer> customer)
        {
            _customer = customer;

        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel lvm)
        {


            var kayıt = _customer.GetRecord(x => x.Email == lvm.Email && x.Password == lvm.Password);
            if (kayıt != null)
            {

                var claims = new List<Claim>()
                    {
                        new Claim("ID", kayıt.ID.ToString()),
                        new Claim(ClaimTypes.Email, lvm.Email),
                        new Claim(ClaimTypes.Anonymous, lvm.Password)

                    };


                var user = new ClaimsIdentity(claims, "Login");


                ClaimsPrincipal principal = new ClaimsPrincipal(user);

                await HttpContext.SignInAsync(principal);

                return RedirectToAction("ProductList", "Customer", new { area = "User" });



            }
            return View();
        }
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync();
            return RedirectToAction("Login");
        }


        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(Customer C)
        {

            if (C.Name != null && C.Surname != null && C.Email != null && C.Password != null)
            {
                return _customer.Add(C) ? RedirectToAction("Login", "Account") : View();
            }
            ViewBag.LessonError = "All blanks must be filled.";
            return View();
        }
    }

}
