﻿using BlackFriday.Core.Service;
using BlackFriday.Model.Entities;
using BlackFriday.WebUI.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace BlackFriday.WebUI.Controllers
{
    public class ProductController : Controller
    {
        private readonly ICoreService<Product> _productdb;
        private readonly ICoreService<Customer> _customerdb;
        public ProductController(ICoreService<Product> productdb, ICoreService<Customer> customerdb)
        {
            _productdb = productdb;
            _customerdb = customerdb;
        }
        
        public IActionResult ProductList()
        {
            return View(_productdb.GetAll());
        }
        
        public IActionResult GetProduct(int id)
        {
            return View(_productdb.GetByID(id));
        }
    }
}
