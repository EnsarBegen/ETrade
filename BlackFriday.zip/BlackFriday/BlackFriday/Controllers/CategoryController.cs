﻿using BlackFriday.Core.Service;
using BlackFriday.Model.Entities;
using Microsoft.AspNetCore.Mvc;

namespace BlackFriday.WebUI.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICoreService<Category> _categorydb;
        public CategoryController(ICoreService<Category> categorydb)
        {
            _categorydb= categorydb;
        }

        public IActionResult CategoryList()
        {
            return View(_categorydb.GetAll());
        }
       
    }
}
