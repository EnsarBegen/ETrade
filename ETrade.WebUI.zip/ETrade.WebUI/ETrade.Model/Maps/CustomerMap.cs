﻿using ETrade.Core.Map;
using ETrade.Model.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ETrade.Model.Maps
{
    public class CustomerMap :CoreMap<Customer>
    {
        public override void Configure(EntityTypeBuilder<Customer> builder)
        {
            builder.Property(x => x.Name).HasMaxLength(20).IsRequired(true);
            builder.Property(x => x.Surname).HasMaxLength(20).IsRequired(true);
            builder.Property(x => x.Email).HasMaxLength(50).IsRequired(true);
            builder.Property(x => x.Password).HasMaxLength(10).IsRequired(true);
            builder.Property(x => x.PhoneNumber).HasMaxLength(15).IsRequired(false);


        }
    }
}
