﻿using Microsoft.AspNetCore.Mvc;

namespace ETrade.WebUI.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
