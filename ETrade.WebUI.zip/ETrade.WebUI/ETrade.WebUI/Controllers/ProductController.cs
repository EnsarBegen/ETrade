﻿using Microsoft.AspNetCore.Mvc;

namespace ETrade.WebUI.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
