﻿using System;

namespace ETrade.Core
{
    public class Class1
    {
    }
}
